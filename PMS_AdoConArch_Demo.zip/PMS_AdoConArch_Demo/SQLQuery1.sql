﻿create schema swathi
create table[swathi].[Product1]([Id] INT Identity(1,1) Primary key Not null,
[Product_name] Varchar(20) null,
[Price] decimal(10) null, [Expdate] DATE null);
Insert into [swathi].[Product1] ([Product_name],[Price],[Expdate])
values('Soaps',100.00,'10/2/2018')
alter proc swathi.InsertProduct1
@pName varchar (20),
@price decimal,
@edate Date
as
insert into [swathi].[Product1] values(@pName, @price, @edate);
select * from swathi.Product1