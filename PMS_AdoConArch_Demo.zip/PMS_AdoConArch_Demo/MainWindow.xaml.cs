﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PMS_AdoConArch_Demo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ProductDAL dal = new ProductDAL();

        public MainWindow()
        {
            InitializeComponent();
        }

        public bool IsInputValid()
        {
            bool isValid = true;
            StringBuilder sb = new StringBuilder();

            if (cmbProdName.Text == null | cmbProdName.Text == string.Empty | cmbProdName.Text.Length < 1)
            {
                sb.Append("\nProduct-Name is Mandatory!");
                isValid = false;
            }
            if (txtPrice.Text == null | txtPrice.Text == string.Empty | txtPrice.Text.Length < 1)
            {
                sb.Append("\nProduct-Price is Mandatory!");
                isValid = false;
            }
            if (dpExpDate.Text == null | dpExpDate.Text == string.Empty | dpExpDate.Text.Length < 1)
            {
                sb.Append("\nExpiry Date is Mandatory!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new PMS_Exception(sb.ToString());
            }

            return isValid;
        }

        public void PopulateUI()
        {
            IEnumerable<Product> prods = dal.SelectAll();
            dgProducts.ItemsSource = prods;
            cmbProdName.ItemsSource = prods;
            cmbProdName.DisplayMemberPath = "ProdName";
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateUI();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (IsInputValid())
                {
                    Product p = new Product
                    {
                        ProdName = cmbProdName.Text,
                        Price = Convert.ToDecimal(txtPrice.Text),
                        ExpDate = Convert.ToDateTime(dpExpDate.Text)
                    };
                    dal.Insert(p);
                    MessageBox.Show("Inserted!");
                    PopulateUI();
                }
            }
            catch (PMS_Exception ex1)
            {
                MessageBox.Show(ex1.Message);
            }
            catch (Exception ex2)
            {
                MessageBox.Show(ex2.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void cmbProdName_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Product p = (Product) cmbProdName.SelectedItem;

            MessageBox.Show(p.Id.ToString());
        }
    }
}
